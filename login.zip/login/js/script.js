const bt = document.querySelector("#btVerificar");

const txUsuario = document.querySelector("#txUsuario");
const txPass = document.querySelector("#txSenha");
const txConfirmar = document.querySelector("#txConfirmar");

const msg = document.querySelector("#mensagem");
const msgConfirmar = document.querySelector("#msgConfirmar");
const msgFinal = document.querySelector("#msgFinal");

txPass.addEventListener("input", function() {
    msg.className = "";

    if (txPass.value.length < 3) {
        msg.textContent = "Senha fraca";
        msg.classList.add("vermelho");
    }
    else if (txPass.value.length < 6) {
        msg.textContent = "Senha intermediária";
        msg.classList.add("amarelo");
    }
    else {
        msg.textContent = "Senha forte";
        msg.classList.add("verde");
    }
});

function verificarSenhas() {
    msgConfirmar.className = "";

    if (txConfirmar.value !== txPass.value) {
        msgConfirmar.textContent = "As senhas devem ser iguais!";
        msgConfirmar.classList.add("vermelho");
    }
    else if (txConfirmar.value !== "") {
        msgConfirmar.textContent = "As senhas são iguais!";
        msgConfirmar.classList.add("verde");
    }
    else {
        msgConfirmar.textContent = "";
    }
}

txConfirmar.addEventListener("input", verificarSenhas);
txPass.addEventListener("input", verificarSenhas);

bt.addEventListener("click", function() {
    msgFinal.className = "";

    if (txUsuario.value.trim().length < 3) {
        msgFinal.textContent = "O usuário deve ter no mínimo 3 caracteres!";
        msgFinal.classList.add("vermelho");
    }
    else if (txPass.value !== txConfirmar.value) {
        msgFinal.textContent = "As senhas devem ser iguais!";
        msgFinal.classList.add("vermelho");
    }
    else {
        localStorage.setItem("usuario", txUsuario.value.trim());

        window.location.href = "dashboard.html";
    }
});